from wifi import support as wifi_support
if wifi_support:
    import socket
    import ssl
import tar
import garbage
import os
import gc

class INFO:
    NAME = "official"
    VER = "1.6.0"
    TARGET = "cwii"


class OFW:
    DOMAIN = "github.com"
    REPO = "k0dekiller/deimos"
    INDEX = "k0dekiller/deimos-apps"


def get_stream(host: bytes, path: bytes):
    garbage.collect()
    addr = socket.getaddrinfo(host, 443)[0][-1]
    s = socket.socket()
    s.connect(addr)
    garbage.collect()
    s = ssl.wrap_socket(s)
    
    s.write(b"GET " + path + b" HTTP/1.0\r\nHost: " + host + b"\r\n\r\n")
    
    loc = None
    found = True
    while True:
        garbage.collect()
        line = s.readline()
        if line == b"\r\n" or line == b"":
            break
        if line.startswith(b"Location: "):
            loc = line.replace(b"Location: ", b"").rstrip(b"\r\n")
        if line.startswith(b"HTTP/"):
            status = line.split(b" ")[1]
            if status != b"200":
                found = False
        del line
    
    if not loc:
        if found:
            return s
        else:
            return False
    s.close()
    loch = loc.split(b"/", 3)[2]
    loc = b"/" + loc.split(b"/", 3)[3]
    return get_stream(loch, loc)


def download(repo: str | None = None, ver: str = "latest"):
    url = bytes("/" + (repo if repo else OFW.REPO) + "/releases", "utf-8")
    if ver == "latest":
        url += b"/latest/download"
    else:
        url += b"/download/" + bytes(ver, "utf-8")
    url += b"/deimos.tar"
    r = get_stream(bytes(OFW.DOMAIN, "utf-8"), url)
    if not r:
        return False
    with open("/deimos.tar", "wb") as f:
        i = 0
        while True:
            chunk = r.read(512)
            if not chunk:
                break
            print("[FWUP] Copying chunk " + (str(((i := i+1)-1))))
            f.write(chunk)
        print("[FWUP] Done downloading")
    
    
    r.close()
    garbage.collect()
    
    print("[FWUP] Extracting tar into /")
    tar.extract("/deimos.tar", "/")
    os.remove("/deimos.tar")
    return True
