from cwio import *
from cwio.const import *
import ui
import os

name = "File Editor"

PAGE = SCR.WIDTH // 4

def normalize(s: str, page: int):
    out = ""
    for line in s.splitlines():
        out += line[PAGE * page:PAGE * (page + 1)] + "\n"
    return out


def printlines(s: str, pos: int, oldpos: int, writeall: bool = True):
    refresh = writeall
    
    lines = s[:pos].count("\n")
    oldlines = (s[:oldpos].count("\n") if oldpos != pos else lines)
    last = s[:pos].split("\n")[-1]
    lastlen = len(last)
    norm = normalize(s, lastlen // PAGE)
    out = "\n".join(norm.splitlines()[lines:lines + 7])
    curr = out.split("\n", 1)[0]
    total = s.split("\n", lines + 1)[-2]
    
    if lines != oldlines:
        refresh = True
    
    if refresh:
        screen.clear()
    else:
        screen.rect(0, 0, SCR.WIDTH, 8, SCR.COLOR.WHITE)
    screen.write((out if refresh else curr), 0, 0, SCR.COLOR.BLACK, font.miniwi)
    screen.write("|", (lastlen % 48) * 4, 0, SCR.COLOR.DARK, font.miniwi)
    return (len(total), lastlen)


def main():
    file = ui.choose_file()
    if file == -1:
        return None
    with open(file, "r") as f:
        buf = f.read()
    
    oldpos = None
    pos = 0
    
    refresh = True
    shift = False
    tools = False
    while True:
        totallen, lastlen = printlines(buf, pos, oldpos, writeall = refresh)
        tonext = totallen - lastlen + 1
        refresh = False
        screen.apply()
        while keyboard.pressed_any():
            pass
        key = keyboard.get_next()
        char = None
        oldpos = pos
        if key == KB.KEY.HOME:
            sel = ui.choose(("Save", "Save and exit", "Save as...", "Save as... and exit", "Exit without saving"))
            exit = False
            if sel in [1, 3, 4]:
                exit = True
            if sel in [0, 1]:
                with open(file, "w") as f:
                    f.write(buf)
                
            elif sel in [2, 3]:
                name = None
                while not name:
                    name = ui.ask("Save as")
                    if not "\x00" in name:
                        with open(name, "w") as f:
                            f.write(buf)
                        
                        break
                    name = None
            
            if exit:
                break
            refresh = True
        elif key == KB.KEY.SHIFT:
            shift = True
        elif key == KB.KEY.TOOLS:
            tools = True
        elif shift and not tools:
            shift = False
            tools = False
            if key == KB.KEY.LPAREN:
                char = "="
            elif key == KB.KEY.RPAREN:
                char = ","
            elif key == KB.KEY.ADD:
                char = "\""
            elif key == KB.KEY.MULTIPLY:
                char = "^"
            elif key == KB.KEY.DIVIDE:
                char = "%"
            elif key == KB.KEY.DOT:
                char = "!"
            
        elif tools and not shift:
            shift = False
            tools = False
            if key == KB.KEY.RPAREN:
                char = ";"
            elif key == KB.KEY.DOT:
                char = "?"
            
        elif shift and tools:
            shift = False
            tools = False
        else:
            if key == KB.KEY.BKSPACE:
                char = -1
            elif key == KB.KEY.LEFT:
                pos -= (1 if pos > 0 else 0)
            elif key == KB.KEY.RIGHT:
                pos += (1 if pos < len(buf) else 0)
            elif key == KB.KEY.UP:
                pos -= (lastlen + 1 if pos - (lastlen + 1) >= 0 else lastlen)
            elif key == KB.KEY.DOWN:
                pos += (tonext if pos + tonext <= len(buf) else 0)
            elif key == KB.KEY.LPAREN:
                char = "("
            elif key == KB.KEY.RPAREN:
                char = ")"
            elif key == KB.KEY.ADD:
                char = "+"
            elif key == KB.KEY.SUBTRACT:
                char = "-"
            elif key == KB.KEY.MULTIPLY:
                char = "*"
            elif key == KB.KEY.DIVIDE:
                char = "/"
            elif key == KB.KEY.DOT:
                char = "."
            elif key == KB.KEY.POWER_10:
                char = " "
            elif key == KB.KEY.FORMAT:
                char = ui.ask("Insert text")
            
        if char:
            if char == -1:
                if pos > 0:
                    buf = buf[:pos - 1] + buf[pos:]
                    ((pos := pos-1)+1)
            else:
                refresh = True
                buf = buf[:pos] + char + buf[pos:]
                pos += len(char)
